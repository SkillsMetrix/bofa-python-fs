from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.services.employee_service import (
    create_employee,
    promote_employee,
    list_employees
)

from app.utils.monitoring import REQUEST_COUNTER

router = APIRouter()


@router.post("/add")
def add_employee(
        name: str,
        department: str,
        salary: float,
        db: Session = Depends(get_db)
):

    REQUEST_COUNTER.labels(endpoint="add_employee").inc()

    return create_employee(db, name, department, salary)


@router.get("/all")
def get_employees(db: Session = Depends(get_db)):

    REQUEST_COUNTER.labels(endpoint="list_employee").inc()

    return list_employees(db)


@router.post("/promote")
def promote(
        emp_id: int,
        increment: float,
        db: Session = Depends(get_db)
):

    REQUEST_COUNTER.labels(endpoint="promote_employee").inc()

    return promote_employee(db, emp_id, increment)