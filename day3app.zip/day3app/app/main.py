from fastapi import FastAPI
from prometheus_client import make_asgi_app

from app.database import Base, engine
from app.routers import employee_router

from app.models import employee_model
from app.models import audit_model

app = FastAPI(title="FastAPI Enterprise Training")

Base.metadata.create_all(bind=engine)

app.include_router(
    employee_router.router,
    prefix="/employees",
    tags=["Employees"]
)

metrics_app = make_asgi_app()
app.mount("/metrics", metrics_app)


@app.get("/")
def health():

    return {"status": "running"}