from fastapi import FastAPI


from .database import engine
from . import userschema,dml,drl

userschema.Base.metadata.create_all(bind=engine)

app = FastAPI()

app.include_router(dml.router)
app.include_router(drl.router)


