
from pydantic import BaseModel,EmailStr

# define schema
class Users(BaseModel):
    username: str
    email: str

class UserCreate(BaseModel):
    id: int
    email: EmailStr
    password: str

class UserOut(BaseModel):
    email: EmailStr

    class Config:
        orm_mode= True

class UserLogin(BaseModel):
    
    email: EmailStr
    password: str

class Toke(BaseModel):
     
    access_token: str
    token_type: str

class TokenData(BaseModel):
    id: str
    