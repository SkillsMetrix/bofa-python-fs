from fastapi import APIRouter,HTTPException,status,Depends
from fastapi.params import Body
from pydantic import BaseModel
from sqlalchemy.orm import Session
from .usermodel import Users
from .database import get_connection
from . import userschema
router = APIRouter(tags=["USER  POST,UPDATE and DELETE"])
# list
users = []

# reused Function
def findByID(id):
    for i,p in enumerate(users):
        if p['id'] == id:
            return i
# Post into Users

@router.post('/adduser',status_code=status.HTTP_201_CREATED)
def adduser(payload: Users,db:Session=Depends(get_connection)):
    data= userschema.UserApp(**payload.model_dump())
    db.add(data)
    db.commit()
    
    return {"message": "User Added"}

# delete the record
@router.delete('/deleteuser/{name}')
def loadUser(name: str, db: Session = Depends(get_connection)):
    post = db.query(userschema.UserApp).filter(
        userschema.UserApp.username == name).first()
    if not post:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Given Name Not Found")
    db.delete(post)
    db.commit()
    return {"data": "User Deleted"}

# update the record

# Post into Users
@router.put('/updateuser/{id}')
def adduser(id:int,payload: Users):
    post = findByID(id)
    if post == None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,detail="Given ID Not Found")
    data = payload.model_dump()
    data['id'] = id
    users[post]= data
    return {"message": "User updated"}
