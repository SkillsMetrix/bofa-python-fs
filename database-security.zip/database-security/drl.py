from fastapi import APIRouter, HTTPException, status, Depends
from fastapi.params import Body
from pydantic import BaseModel
from sqlalchemy.orm import Session
from .usermodel import Users
from .database import get_connection
from . import userschema

router = APIRouter(tags=["USER  Loads Only"])


# return all users
@router.get('/loadusers')
def loadUsers(db: Session = Depends(get_connection)):
    users = db.query(userschema.UserApp).all()
    return {"message": users}

# return specific user


@router.get('/loaduser/{name}')
def loadUser(name: str, db: Session = Depends(get_connection)):
    post = db.query(userschema.UserApp).filter(
        userschema.UserApp.username == name).first()
    if not post:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Given Name Not Found")
    return {"data": post}
