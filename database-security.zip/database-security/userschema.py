from .database import Base
from sqlalchemy import Column,String,Integer
class UserApp(Base):
    __tablename__="UserApp"

    username=Column(String)
    email=Column(String,primary_key=True)

class User(Base):
    __tablename__="users"
    id=Column(Integer,primary_key=True)
   
    email=Column(String,primary_key=True)
    password=Column(String)