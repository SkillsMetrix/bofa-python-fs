from fastapi import APIRouter,HTTPException,status
from fastapi.params import Body
from pydantic import BaseModel
from random import randrange
from .usermodel import Users
from .database import engine
from . import userschema

 router = APIRouter(tags=["USER  Loads Only"])

# list
users = []

# reused Function
def findByID(id):
    for i,p in enumerate(users):
        if p['id'] == id:
            return i


# return all users
@router.get('/loadusers')
def loadUsers():
    return {"message": users}

# return specific user


@router.get('/loaduser/{id}')
def loadUser(id: int):
    post = findByID(id)
    if not post:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,detail="Given ID Not Found")
    return {"data": post}

