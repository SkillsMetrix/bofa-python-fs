from fastapi import APIRouter,HTTPException,status
from fastapi.params import Body
from pydantic import BaseModel
from random import randrange
from .usermodel import Users
from .database import engine
from . import userschema

 

router = APIRouter(tags=["USER  POST,UPDATE and DELETE"])



# list
users = []

# reused Function
def findByID(id):
    for i,p in enumerate(users):
        if p['id'] == id:
            return i



# Post into Users
@router.post('/adduser',status_code=status.HTTP_201_CREATED)
def adduser(payload: Users):
    data = payload.model_dump()
    data['id'] = randrange(0, 1000)
    users.append(data)
    print(users)
    return {"message": "User Added"}



# delete the record
@router.delete('/deleteuser/{id}')
def deleteUser(id: int):
    post = findByID(id)
    if post == None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,detail="Given ID Not Found")
    users.pop(post)
    return {"data": "User Deleted"}

# update the record

# Post into Users
@router.put('/updateuser/{id}')
def adduser(id:int,payload: Users):
    post = findByID(id)
    if post == None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,detail="Given ID Not Found")
    data = payload.model_dump()
    data['id'] = id
    users[post]= data
    return {"message": "User updated"}
