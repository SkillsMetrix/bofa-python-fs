from sqlalchemy import text


def add_employee(db, name, department, salary):

    db.execute(
        text("""
        INSERT INTO employees(name, department, salary)
        VALUES(:name,:dept,:salary)
        """),
        {"name": name, "dept": department, "salary": salary}
    )


def update_salary(db, emp_id, increment):

    db.execute(
        text("""
        UPDATE employees
        SET salary = salary + (salary * :inc / 100)
        WHERE id = :id
        """),
        {"inc": increment, "id": emp_id}
    )


def insert_audit(db, emp_id):

    db.execute(
        text("""
        INSERT INTO salary_audit(emp_id, action)
        VALUES(:id,'SALARY UPDATED')
        """),
        {"id": emp_id}
    )


def get_all_employees(db):

    result = db.execute(text("SELECT * FROM employees"))

    return result.fetchall()