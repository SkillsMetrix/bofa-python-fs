from fastapi import FastAPI
from prometheus_client import make_asgi_app
from sloapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIMiddleware
from app.utils.ratelimiter import limeter
from app.database import Base, engine
from app.routers import employee_router

from app.models import employee_model
from app.models import audit_model

app = FastAPI(title="FastAPI Enterprise Training")

Base.metadata.create_all(bind=engine)

app.state.limiter= limiter
app.add_middleware(SlowAPIMiddleware)

app.include_router(
    employee_router.router,
    prefix="/employees",
    tags=["Employees"]
)

metrics_app = make_asgi_app()
app.mount("/metrics", metrics_app)


@app.get("/")
def health():

    return {"status": "running"}