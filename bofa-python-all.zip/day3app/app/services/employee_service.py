from app.repositories.employee_repository import (
    add_employee,
    update_salary,
    insert_audit,
    get_all_employees
)

from app.utils.logger import logger


def create_employee(db, name, department, salary):

    try:

        add_employee(db, name, department, salary)

        db.commit()

        logger.info("Employee added")

        return {"status": "employee created"}

    except Exception as e:

        db.rollback()

        return {"error": str(e)}


def promote_employee(db, emp_id, increment):

    try:

        logger.info("Starting transaction")

        update_salary(db, emp_id, increment)

        # rollback demo condition
        if increment > 50:
            raise Exception("Increment too high")

        insert_audit(db, emp_id)

        db.commit()

        logger.info("Transaction committed")

        return {"status": "promotion successful"}

    except Exception as e:

        logger.error("Transaction failed, rolling back")

        db.rollback()

        return {"status": "rollback", "error": str(e)}


def list_employees(db):

    return get_all_employees(db)