from fastapi.responses import JSONResponse


def global_exception_handler(request, exc):

    return JSONResponse(
        status_code=500,
        content={
            "message": "Internal server error",
            "error": str(exc)
        }
    )