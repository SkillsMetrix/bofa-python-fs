from prometheus_client import Counter

REQUEST_COUNTER = Counter(
    "employee_api_requests_total",
    "Total API requests",
    ["endpoint"]
)