from fastapi import FastAPI, UploadFile, File
import pandas as pd
import io
from fastapi.responses import StreamingResponse

app = FastAPI()

 
def process_students(df):
    
    
    df["grade"] = df["marks"].apply(lambda x: "A" if x >= 90 else
                                              "B" if x >= 75 else
                                              "C" if x >= 60 else "Fail")
    
  
    df["status"] = df["marks"].apply(lambda x: "Pass" if x >= 60 else "Fail")

    return df



@app.post("/upload-students")
async def upload_students(file: UploadFile = File(...)):

    contents = await file.read()

    df = pd.read_csv(io.StringIO(contents.decode("utf-8")))

    processed_df = process_students(df)

    return {
        "message": "File processed successfully",
        "records": processed_df.to_dict(orient="records")
    }

