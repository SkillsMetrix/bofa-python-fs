import pandas as pd

employees = [
    {"id":101,"name":"Alice","age":28,"department":"HR","salary":50000,"experience":3},
    {"id":102,"name":"Bob","age":35,"department":"IT","salary":70000,"experience":8},
    {"id":103,"name":"Charlie","age":40,"department":"Finance","salary":80000,"experience":12},
    {"id":104,"name":"David","age":25,"department":"IT","salary":60000,"experience":2},
    {"id":105,"name":"Eva","age":30,"department":"HR","salary":55000,"experience":5},
    {"id":106,"name":"Frank","age":45,"department":"Finance","salary":90000,"experience":15},
    {"id":107,"name":"Grace","age":29,"department":"IT","salary":65000,"experience":4},
    {"id":108,"name":"Helen","age":38,"department":"HR","salary":72000,"experience":10}
]

# convert to dataframe
df= pd.DataFrame(employees)
#print(df)

#print(df.info())

#print(df.describe())

print(df[["name","salary"]])

high_salary= df[df["salary"] > 70000]
#print(high_salary)


high_salary= df[(df["salary"] > 60000) & (df["experience"] > 5)]
#print(high_salary)

avg_salary= df.groupby("department")["salary"].mean()
#print(avg_salary)

df= df.drop_duplicates()
#print(df)

def calculate_tax(salary):
    return salary *0.20

df["tax"]= df["salary"].apply(calculate_tax)
#print(df)

# save the data in csv

#df.to_csv("employee_data.csv",index=False)
#print("File created")

""" Display the first 3 rows of the dataset.
df.head(3)
Find employees who belong to the IT department.
df[df["department"] == "IT]
Sort employees by age in ascending order.
df.sort_values(by="age")
Sort employees by salary in descending order.
df.sort_values(by="age",ascending=False)
Create a new column called bonus which is 10% of salary
df["bonus"] =df["salary"] *0.10
Find the average salary of all employees.
Find the maximum salary in the dataset.
Find the employee who has the highest salary. """

df.head(3)