import pandas as pd
employees = [
    {"id":101, "name":"Alice", "salary":50000},
    {"id":102, "name":"Bob", "salary":60000},
    {"id":103, "name":"Charlie", "salary":70000}

]
# without panda
for emp in employees:
    emp["salary"]= emp["salary"] * 1.10
    #print(emp)

# with panda

data={
    "id":[101,102,103],
    "name":["Alice","Bob","Charlie"],
    "salary":[50000,60000,55000]
}
df= pd.DataFrame(data)
df["salary"]= df["salary"] * 1.10
print(df)

print(df[df["salary"]> 55000])
