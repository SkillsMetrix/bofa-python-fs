from fastapi import FastAPI
from app.database import Base, engine

# Import models so SQLAlchemy knows them
from app.models import employee_model
from app.models import salary_audit_model

from app.routers import employee_router

app = FastAPI()

Base.metadata.create_all(bind=engine)

app.include_router(
    employee_router.router,
    prefix="/employees",
    tags=["Employees"]
)

@app.get("/")
def health():
    return {"message": "FastAPI SQLite running"}