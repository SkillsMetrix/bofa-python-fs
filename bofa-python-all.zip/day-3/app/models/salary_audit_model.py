from sqlalchemy import Column, Integer, String
from app.database import Base


class SalaryAudit(Base):

    __tablename__ = "salary_audit"

    id = Column(Integer, primary_key=True, index=True)
    emp_id = Column(Integer)
    action = Column(String)