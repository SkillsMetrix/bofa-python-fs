from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

 DATABASE_URL = "oracle+oracledb://hr:password@localhost:1521/?service_name=XEPDB1"

engine = create_engine(DATABASE_URL)

SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine
)

Base = declarative_base()

# pip install oracledb