from pydantic import BaseModel


class SalaryUpdate(BaseModel):

    emp_id: int
    increment_percent: float