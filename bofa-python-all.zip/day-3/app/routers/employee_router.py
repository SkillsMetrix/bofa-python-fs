from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import text

from app.database import get_db
from app.schemas.employee_schema import SalaryUpdate
from app.services.employee_service import promote_employee

router = APIRouter()


# -----------------------------
# Add Employee
# -----------------------------
@router.post("/add")
def add_employee(
        name: str,
        department: str,
        salary: float,
        db: Session = Depends(get_db)
):

    db.execute(
        text("""
        INSERT INTO employees(name, department, salary)
        VALUES(:name,:department,:salary)
        """),
        {
            "name": name,
            "department": department,
            "salary": salary
        }
    )

    db.commit()

    return {"message": "Employee added successfully"}


# -----------------------------
# Get All Employees
# -----------------------------
@router.get("/all")
def get_all_employees(db: Session = Depends(get_db)):

    result = db.execute(
        text("SELECT * FROM employees")
    )

    employees = result.fetchall()

    return {"employees": employees}


# -----------------------------
# Get Employee By ID
# -----------------------------
@router.get("/{emp_id}")
def get_employee(emp_id: int, db: Session = Depends(get_db)):

    result = db.execute(
        text("SELECT * FROM employees WHERE id = :emp_id"),
        {"emp_id": emp_id}
    )

    employee = result.fetchone()

    if not employee:
        raise HTTPException(status_code=404, detail="Employee not found")

    return {"employee": employee}


# -----------------------------
# Promote Employee
# (Transaction example)
# -----------------------------
@router.post("/promote")
def promote(
        request: SalaryUpdate,
        db: Session = Depends(get_db)
):

    return promote_employee(
        db,
        request.emp_id,
        request.increment_percent
    )


# -----------------------------
# Delete Employee
# -----------------------------
@router.delete("/{emp_id}")
def delete_employee(emp_id: int, db: Session = Depends(get_db)):

    result = db.execute(
        text("DELETE FROM employees WHERE id = :emp_id"),
        {"emp_id": emp_id}
    )

    db.commit()

    if result.rowcount == 0:
        raise HTTPException(status_code=404, detail="Employee not found")

    return {"message": "Employee deleted successfully"}