from app.repositories.employee_repository import (
    update_employee_salary,
    insert_audit
)


def promote_employee(db, emp_id, increment):

    try:

        # Step 1 Update salary
        update_employee_salary(db, emp_id, increment)

        # Step 2 Insert audit log
        insert_audit(db, emp_id)

        # Commit transaction
        db.commit()

        return {
            "status": "success",
            "message": "Salary updated"
        }

    except Exception as e:

        # Rollback if failure
        db.rollback()

        return {
            "status": "failed",
            "error": str(e)
        }