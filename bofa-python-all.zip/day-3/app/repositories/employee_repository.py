from sqlalchemy import text


def update_employee_salary(db, emp_id, increment):

    query = text("""
        UPDATE employees
        SET salary = salary + (salary * :increment / 100)
        WHERE id = :emp_id
    """)

    db.execute(query, {
        "emp_id": emp_id,
        "increment": increment
    })


def insert_audit(db, emp_id):

    query = text("""
        INSERT INTO salary_audit(emp_id, action)
        VALUES(:emp_id, 'SALARY UPDATED')
    """)

    db.execute(query, {"emp_id": emp_id})