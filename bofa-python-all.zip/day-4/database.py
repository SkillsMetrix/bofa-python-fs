
from pymongo import MongoClient

MONGO_URL="mongodb+srv://admin:admin123@skillsmetrix.1wsa5ut.mongodb.net/?appName=skillsmetrix"

client= MongoClient(MONGO_URL)
db= client["bofa"]
user_collection= db["employees"]