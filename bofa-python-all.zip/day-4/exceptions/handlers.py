
from fastapi.responses import JSONResponse
from fastapi import Request
from .custom_exceptions import UserNotFoundException

def register_exception_handlers(app):

    @app.exception_handler(Exception)
    async def global_exception_handler(request: Request,exc: Exception):
        return JSONResponse(
            status_code=500,
            content={
                "message": "Internal Server Error",
                "detail": str(exc)
            }
        )
    
    @app.exception_handler(UserNotFoundException)
    async def user_not_found_handler(request: Request,exc: UserNotFoundException):
        return JSONResponse(
            status_code=404,
            content={
                "message": f"User {exc.name} not found"
            }
        )