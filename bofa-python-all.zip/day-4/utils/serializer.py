
def user_serializer(user):

    return{
        "id": str(user["_id"]),
        "uname": user["uname"],
        "email": user["email"],
    }