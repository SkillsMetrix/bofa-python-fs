
class UserModel:
    def __init__(self,uname,email):
        self.uname=uname
        self.email=email