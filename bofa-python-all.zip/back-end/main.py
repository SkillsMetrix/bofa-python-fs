from fastapi import FastAPI, Depends, HTTPException
from database import SessionLocal, engine, Base
from fastapi.middleware.cors import CORSMiddleware
from auth import verify_token
from schemas import StudentCreate
import crud
from auth import create_token

app = FastAPI()
origins = [
    "http://localhost:3000",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
async def startup():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


async def get_db():
    async with SessionLocal() as session:
        yield session


# -----------------------------
# Authentication
# -----------------------------

@app.post("/login")
def login():

    token = create_token("admin")

    return {"access_token": token}


# -----------------------------
# CRUD APIs
# -----------------------------

@app.post("/students")
async def add_student(student: StudentCreate, db=Depends(get_db)):

    return await crud.create_student(db, student)


@app.get("/students")
async def get_students(db=Depends(get_db)):

    return await crud.get_students(db)


@app.delete("/students/{student_id}")
async def delete_student(
        student_id: int,
        db=Depends(get_db),
        user=Depends(verify_token)  # security check
):

    student = await crud.delete_student(db, student_id)

    if not student:
        raise HTTPException(status_code=404, detail="Student not found")

    return {"message": "Deleted"}