from sqlalchemy import Column, Integer, String, Index
from database import Base

class Student(Base):

    __tablename__ = "students"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String)
    email = Column(String, unique=True, index=True)
    course = Column(String)

Index("idx_student_email", Student.email)