from models import Student
from sqlalchemy.future import select


async def create_student(db, student):

    new_student = Student(**student.dict())
    db.add(new_student)
    await db.commit()
    await db.refresh(new_student)

    return new_student


async def get_students(db):

    result = await db.execute(select(Student))
    return result.scalars().all()


async def delete_student(db, student_id):

    result = await db.execute(select(Student).where(Student.id == student_id))
    student = result.scalar_one_or_none()

    if student:
        await db.delete(student)
        await db.commit()

    return student