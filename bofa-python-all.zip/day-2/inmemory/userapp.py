from fastapi import FastAPI,HTTPException,status
from fastapi.params import Body
from pydantic import BaseModel
from random import randrange
from usermodel import Users
app = FastAPI()

# list
users = []

# reused Function
def findByID(id):
    for i,p in enumerate(users):
        if p['id'] == id:
            return i


# return all users
@app.get('/loadusers')
def loadUsers():
    return {"message": users}

# return specific user


@app.get('/loaduser/{id}')
def loadUser(id: int):
    post = findByID(id)
    if not post:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,detail="Given ID Not Found")
    return {"data": post}

# Post into Users
@app.post('/adduser',status_code=status.HTTP_201_CREATED)
def adduser(payload: Users):
    data = payload.model_dump()
    data['id'] = randrange(0, 1000)
    users.append(data)
    print(users)
    return {"message": "User Added"}



# delete the record
@app.delete('/deleteuser/{id}')
def deleteUser(id: int):
    post = findByID(id)
    if post == None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,detail="Given ID Not Found")
    users.pop(post)
    return {"data": "User Deleted"}

# update the record

# Post into Users
@app.put('/updateuser/{id}')
def adduser(id:int,payload: Users):
    post = findByID(id)
    if post == None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,detail="Given ID Not Found")
    data = payload.model_dump()
    data['id'] = id
    users[post]= data
    return {"message": "User updated"}
