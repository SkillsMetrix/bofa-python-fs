
from pydantic import BaseModel
# define schema
class Users(BaseModel):
    username: str
    email: str