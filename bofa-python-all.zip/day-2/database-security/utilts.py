
from passlib.context import CryptContext
pwd_context=CryptContext(schemes=["bcrypt"],deprecated="auto")

def hash(password:str):
    password= password.strip()
    if len(password.encode("utf-8")) >72:
        raise ValueError("Password cant excced")
    return pwd_context.hash(password)
    
def verify(plain_password,hashed_password):
    return pwd_context.verify(plain_password,hashed_password)
