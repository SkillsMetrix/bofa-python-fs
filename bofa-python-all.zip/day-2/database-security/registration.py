from fastapi import APIRouter,HTTPException,status,Depends
from fastapi.params import Body
from pydantic import BaseModel
from sqlalchemy.orm import Session
from .usermodel import Users,UserCreate,UserOut
from .database import get_connection
from . import userschema,utilts
router = APIRouter(tags=["User Registration"])


@router.post('/register',status_code=status.HTTP_201_CREATED)
def adduser(payload: UserCreate,db:Session=Depends(get_connection)):

    data= userschema.User(**payload.model_dump())
    hp=utilts.hash(payload.password)
    payload.password=hp
    db.add(data)
    db.commit()
    
    return {"message": "User Registered"}

