from .database import Base
from sqlalchemy import Column,String
class UserApp(Base):
    __tablename__="UserApp"

    username=Column(String)
    email=Column(String,primary_key=True)