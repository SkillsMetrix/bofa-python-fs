
from RBIBase import RBI

class CitiBank(RBI):
     def deposit(self):
        print("CITI deposit called")
     def withdraw(self):
        print("CITI withdraw called")
     def checkBalance(self):
        print("CITI balance called")

bank= CitiBank()
bank.deposit()