
from abc import ABC,abstractmethod
class RBI(ABC):

    @abstractmethod
    def deposit(self):
        pass
    @abstractmethod    
    def withdraw(self):
        pass
    @abstractmethod    
    def checkBalance(self):
        pass
