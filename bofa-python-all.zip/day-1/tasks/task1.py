
user_data=[]

data = int(input('How Many numbers wana add ? '))

print(data)


for i in range(data):
    num= int(input(f" Enter Number {i+1}  "))
    user_data.append(num)
print(f"The List Value is {user_data}")

# calculate even and odd numbers and print

for num in user_data:
    if(num%2==0):
        print(f"{num} is even")
    else:
        print(f"{num} is odd")
# calculate the addition of all the values in array

total=0
for data in user_data:
     
print(f"Addition is {}")
