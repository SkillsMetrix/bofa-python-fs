
def addAge(age):
    if(age < 18):
        raise ValueError("Age must be 18 to Vote")
    print(f"Age is {age}")


try:
    addAge(int(input("Enter age : ")))
except ValueError as e:
    print(e)
