
#create class

class Employee:
    name='Adam'
    
    def __init__(self,name,city):
        self.city=city
        self.name=name

    def show(self):
        print('Method Called ' + self.name)
    
    def takeInput(self,city):
        print(city)


# create object

emp= Employee('sam','Mumbai')
print(emp.name,emp.city)

emp.show()

emp.takeInput('Pune')

 
