
""" name= input('Enter Name ')

print(f"Welcome: {name}") """

val1 =int( input('Enter First Value '))
val2 =int (input('Enter Sec Value '))

sum= val1+val2

print(f'Addition is {sum}')


