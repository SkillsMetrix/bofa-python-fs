
dataA=["20","user",34]
try:
    totalValue=int(dataA[0] + int(dataA[3]))
except(ValueError,TypeError,IndexError) as e:
    print("Error ",e)

except :
    print("Index Value Not Found")