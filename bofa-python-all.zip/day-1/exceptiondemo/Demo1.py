
basicNumber=10
response=0

try:
    response=basicNumber/0

except ZeroDivisionError:
    print('Enter the correct value')

print(response)
print('called post error')