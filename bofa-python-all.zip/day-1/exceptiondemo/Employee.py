
from AllException import *

class Employee:

    def __init__(self,name,age,salary):
        if not name.strip():
            raise EmptyNameError('Employee name is empty')
        
        self.name=name
        self.salary=salary
        self.age=age
    
    def __str__(self):
        return f"Emp Name: {self.name},  Age: {self.age} , Salary: {self.salary}"


try:
    empData=Employee("tom",5000,30)
    print(empData)
    empData=Employee("",1000,30)
    print(empData)

except EmptyNameError as e:
    print("EmptyNameError",e)

print("called after")