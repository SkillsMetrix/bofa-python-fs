
try:
    n=-34
    res=100/n

except ZeroDivisionError:
    print('Enter the correct value')

except ValueError:
    print('Enter a valid Number')

else:
    print("Value : ",res)

finally:
    print("Call it anytime")