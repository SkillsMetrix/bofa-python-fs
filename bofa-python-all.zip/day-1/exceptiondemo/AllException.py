
class InvalidAgeError(Exception):
    pass
class NegativeSalaryError(Exception):
    pass
class EmptyNameError(Exception):
    pass
