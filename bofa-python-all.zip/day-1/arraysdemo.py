
userNames=['admin','manager','qa']

# standard output

for uname in userNames:
    print(f'User Name: {uname} ')

# use index position

for index,uname in enumerate(userNames):
    print(f"Index : {index}, -> {uname.upper()}")