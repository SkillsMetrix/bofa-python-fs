
# simple print statement
print('welcome to python')

# declare var

age=21
name='admin'
city='NY'

print(name,age,city)

# formatting value

print(f'Hola....! {name}, i belongs to {city}, and age is {age}')
