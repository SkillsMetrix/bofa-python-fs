import time
import asyncio
students = ["Alice", "Bob", "Charlie"]

async def fetch_student(name):
    print(f"Fetching {name}")
    await asyncio.sleep(2)
    print(f"{name} data received")


async def main():
    tasks =[]

    for s in students:
        tasks.append(fetch_student(s))
    
    await asyncio.gather(*tasks)
asyncio.run(main())