
import time

def calculateSquare(numbers):
    result=[]

    for n in numbers:
        result.append(n*n)
    return result

numbers= list(range(100000000))

start= time.time()
calculateSquare(numbers)
end= time.time()

print("Time Taken: ",end-start)