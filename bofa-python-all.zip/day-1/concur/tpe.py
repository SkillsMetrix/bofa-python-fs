
from concurrent.futures import ThreadPoolExecutor
import time

students = [
    {"id":1,"name":"Alice","marks":[78,82,91]},
    {"id":2,"name":"Bob","marks":[65,70,72]},
    {"id":3,"name":"Charlie","marks":[88,90,92]},
    {"id":4,"name":"David","marks":[55,60,58]},
    {"id":5,"name":"Eva","marks":[95,93,97]}
]
 
def fetch_student(student):
    print(f"Fetching Students {student['name']}")
    time.sleep(2)
    print(f"{student['name']} data ready")

with ThreadPoolExecutor(max_workers=3)as executor:
    results= executor.map(fetch_student, students)

for r in results:
    print(r)
