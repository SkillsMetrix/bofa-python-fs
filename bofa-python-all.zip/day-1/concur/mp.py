
from multiprocessing import Process

students = [
    {"id":1,"name":"Alice","marks":[78,82,91]},
    {"id":2,"name":"Bob","marks":[65,70,72]},
    {"id":3,"name":"Charlie","marks":[88,90,92]},
    {"id":4,"name":"David","marks":[55,60,58]},
    {"id":5,"name":"Eva","marks":[95,93,97]}
]
 
def calculate_result(student):
    total=0
    for mark in student["marks"]:
        for i in range(1000000):
            total +=mark *i
    print(student["name"], "result processed")

processes= []

for student in students:
     p= Process(target= calculate_result,args=(student,))
     processes.append(p)
     p.start()

for t in processes:
    t.join()
print("All results calculated")
