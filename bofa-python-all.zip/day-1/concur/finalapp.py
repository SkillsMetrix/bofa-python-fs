import time
import threading
students = [
    {"id":1,"name":"Alice","marks":[78,82,91]},
    {"id":2,"name":"Bob","marks":[65,70,72]},
    {"id":3,"name":"Charlie","marks":[88,90,92]},
    {"id":4,"name":"David","marks":[55,60,58]},
    {"id":5,"name":"Eva","marks":[95,93,97]}
]
# IO based example
def fetch_student(student):
    print(f"Fetching Students {student['name']} data")
    time.sleep(2)
    print(f"{student['name']} data loaded")

threads= []

for student in students:
     t= threading.Thread(target= fetch_student,args=(student,))
     threads.append(t)
     t.start()

for t in threads:
    t.join()
print("All students fetched")
