
from flask import Flask, request, jsonify

app = Flask(__name__)

employees = []


@app.route("/create", methods=['POST'])
def createEmp():
    data = request.json

    employee = {
        "id": data["id"],
        "name": data["name"],
        "dept": data["dept"]
    }
    employees.append(employee)

    return jsonify({
        "message": "Employee Created",
        "employee": employee
    })

@app.route("/load", methods=['GET'])
def loadEmp():
    return jsonify(employees)



if __name__ == "__main__":
    print("Starting Flask server...")
    app.run(debug=True)