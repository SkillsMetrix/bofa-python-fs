from fastapi import FastAPI

app = FastAPI()

@app.get("/")
def home():
    return {"message": "FastAPI running inside Docker via Jenkins"}


@app.get("/welcome")
def home():
    return {"message": "Welcome to CI CD"}