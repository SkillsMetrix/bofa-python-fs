
import unittest

from employee import Employee

class TestEmployee(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        print('setup class')
    
    @classmethod
    def tearDownUpClass(cls):
        print('teardown class')
    
    
    def setUp(self):
        print('called before')
        self.emp1= Employee('Corey','shal',5000)
        self.emp2= Employee('sue','smith',6000)
    
    def tearDown(self):
        print('called after')
        pass
        
    
    def test_email(self):
        print('Testing email begins')
        self.assertEqual(self.emp1.email,'Corey.shal@email.com')
        self.assertEqual(self.emp2.email,'sue.smith@email.com')
    

if __name__ == '__main__':
    unittest.main()