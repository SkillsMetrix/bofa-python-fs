from fastapi import FastAPI
from config import settings
import time

app = FastAPI(title=settings.APP_NAME)

app_start_time = None


 

@app.on_event("startup")
async def startup_event():
    global app_start_time
    app_start_time = time.time()
    print("Application starting...")
    print(f"Environment: {settings.APP_ENV}")
    print(f"Database URL: {settings.DB_URL}")


@app.on_event("shutdown")
async def shutdown_event():
    print("Application shutting down...")


 

@app.get("/health")
def health_check():
    return {
        "status": "UP",
        "environment": settings.APP_ENV
    }


 

@app.get("/health/details")
def health_details():
    uptime = time.time() - app_start_time
    return {
        "status": "healthy",
        "app": settings.APP_NAME,
        "environment": settings.APP_ENV,
        "uptime_seconds": round(uptime, 2)
    }


 

@app.get("/employees")
def get_employees():
    return [
        {"id": 1, "name": "John"},
        {"id": 2, "name": "Alice"}
    ]