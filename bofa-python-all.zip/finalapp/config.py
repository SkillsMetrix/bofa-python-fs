import os
from dotenv import load_dotenv

load_dotenv()

class Settings:
    APP_NAME= os.getenv("APP_NAME","FastAPI App")
    APP_ENV= os.getenv("APP_ENV","development")
    DEBUG=os.getenv("DEBUG","False")
    DB_URL=os.getenv("DB_URL")

settings=Settings()