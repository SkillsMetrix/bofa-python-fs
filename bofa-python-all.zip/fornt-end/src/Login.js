import API from "./api"




function Login(){

    const login=async()=>{
        const res= await API.post("/login")
        localStorage.setItem("token",res.data.access_token)
        alert("logged in")
    }

    return(
        <div>
            <h2>Login</h2>
            <button onClick={login}>Login</button>
        </div>
    )
}
export default Login