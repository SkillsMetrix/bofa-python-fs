import logo from './logo.svg';
import './App.css';
import Students from './Students';
import Login from './Login';

function App() {
  return (
    <div className="App">
      <p>FullStack</p>
      <hr/>
      <Students/>
      <hr/>
      <Login/>
    </div>
  );
}

export default App;
