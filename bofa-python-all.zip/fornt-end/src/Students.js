import { useEffect, useState } from"react";
import API from "./api";

// its a component
function Students(){
    // initilaize the state of the student

    const [students,setStudents]= useState([])

    const loadStudents=async()=> {
        try{
            const res= await API.get('/students')
            setStudents(res.data)
        }
        catch(err){
            alert('Error Loading students')
        }
    }
// called during launch
    useEffect(()=>{
        loadStudents()
    },[])

    return (
        <div>
            <h2>User Details</h2>
            <ul>
                {students.map(s=>(
                    <li>{s.name}- {s.email}</li>
                ))}
            </ul>
        </div>
    )
}
export default Students