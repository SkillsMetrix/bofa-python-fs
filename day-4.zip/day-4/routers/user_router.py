
from fastapi import APIRouter
from database import user_collection
import schemas
from utils.serializer import user_serializer
from exceptions.custom_exceptions import UserNotFoundException

router= APIRouter()

@router.post("/adduser")
def add_user(user: schemas.User):

    user_dict= user.dict()
    result= user_collection.insert_one(user_dict)
    return {
        "message":"user added",
        "id": str(result.inserted_id)
    }